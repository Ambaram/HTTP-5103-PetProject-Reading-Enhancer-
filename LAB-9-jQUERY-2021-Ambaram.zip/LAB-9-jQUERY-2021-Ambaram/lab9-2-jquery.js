//LAB 9 - 2 INVENTORY PAGE
$(document).ready(function() {
	
	// hide description //
	
	$('.desc').hide();
	
	// background change //
	
	$('tr').hover( 
		function (){
		$(this).addClass('selected')
		},
		function(){
		$(this).removeClass('selected');
	});
	
	// description display //
	
	$('tr').click( function(){
		$('.desc').hide();
		$(this).find('td').addClass("onclick");
		$(this).find('.desc').slideToggle("slow");
	});
})
