//LAB 9 - 1 FAQ PAGE
// alert("1 - connected");
$(document).ready(function() {
	
	// hide para //
	
	$(".contentBox").hide();
	
	// Paragrah toggle //
	
	$('.panelContainer').click( function(){
		var $myques=$($(this).find('p'));
		$('.contentBox').not($myques.slideToggle(3000)).slideUp('slow');
	});
	
	// Add class
	$('h2').hover( function(){
		$(this).addClass("textHovered")},
		function(){
			$(this).removeClass("textHovered");
		});
	// Text hover //
	
	$('.contentBox').hover(
      function(){ $(this).addClass("textHovered")},
		function(){
			$(this).removeClass("textHovered");
		});	
 });



